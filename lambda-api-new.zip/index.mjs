import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { CloudWatchClient, PutMetricDataCommand } from "@aws-sdk/client-cloudwatch";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
const docClient = DynamoDBDocumentClient.from(client);
const cloudwatch = new CloudWatchClient({ region: process.env.AWS_REGION || "us-east-1" });

const DYNAMODB_TABLE = process.env.DYNAMODB_TABLE || "bitcraft-profession-experience";
const CORS_ORIGIN = process.env.CORS_ORIGIN || "https://d1e3uuzyb30yo2.amplifyapp.com";

const PROFESSIONS = [
  'carpentry', 'farming', 'fishing', 'foraging',
  'forestry', 'hunting', 'leatherworking', 'masonry',
  'mining', 'scholar', 'smithing', 'tailoring'
];

// Query DynamoDB for player data within time range
async function queryPlayerData(playerId, startTime, endTime) {
  const params = {
    TableName: DYNAMODB_TABLE,
    KeyConditionExpression: 'playerId = :playerId AND #ts BETWEEN :startTime AND :endTime',
    ExpressionAttributeNames: {
      '#ts': 'timestamp'
    },
    ExpressionAttributeValues: {
      ':playerId': playerId,
      ':startTime': startTime,
      ':endTime': endTime
    }
  };

  try {
    const command = new QueryCommand(params);
    const result = await docClient.send(command);
    return result.Items || [];
  } catch (error) {
    console.error('Error querying DynamoDB:', error);
    throw error;
  }
}

// Aggregate data by interval (hourly or daily)
function aggregateData(items, interval) {
  if (!interval || interval === 'raw') {
    return items;
  }

  const intervalSeconds = interval === 'hourly' ? 3600 : 86400;
  const buckets = new Map();

  for (const item of items) {
    // Round timestamp down to interval boundary
    const bucketTime = Math.floor(item.timestamp / intervalSeconds) * intervalSeconds;

    if (!buckets.has(bucketTime)) {
      const aggregated = { timestamp: bucketTime };
      for (const prof of PROFESSIONS) {
        aggregated[prof] = [];
      }
      buckets.set(bucketTime, aggregated);
    }

    const bucket = buckets.get(bucketTime);
    for (const prof of PROFESSIONS) {
      if (typeof item[prof] === 'number') {
        bucket[prof].push(item[prof]);
      }
    }
  }

  // Average the values in each bucket
  const aggregated = [];
  for (const [timestamp, bucket] of buckets) {
    const point = { timestamp };
    for (const prof of PROFESSIONS) {
      const values = bucket[prof];
      if (values.length > 0) {
        point[prof] = Math.round(values.reduce((sum, v) => sum + v, 0) / values.length);
      } else {
        point[prof] = 0;
      }
    }
    aggregated.push(point);
  }

  // Sort by timestamp
  aggregated.sort((a, b) => a.timestamp - b.timestamp);

  return aggregated;
}

// Publish custom metrics to CloudWatch
async function publishMetrics(metrics) {
  const metricData = Object.entries(metrics).map(([metricName, value]) => ({
    MetricName: metricName,
    Value: value,
    Unit: 'Count',
    Timestamp: new Date()
  }));

  const command = new PutMetricDataCommand({
    Namespace: 'BitcraftProfession',
    MetricData: metricData
  });

  try {
    await cloudwatch.send(command);
    console.log('Published custom metrics:', metrics);
  } catch (error) {
    console.error('Error publishing metrics:', error);
    // Don't throw - metrics publishing failure shouldn't break the main function
  }
}

// Lambda handler
export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  // CORS headers
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': CORS_ORIGIN,
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  // Handle OPTIONS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Parse query parameters
  const queryParams = event.queryStringParameters || {};
  const playerId = queryParams.playerId;
  const interval = queryParams.interval || 'raw';

  if (!playerId) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'playerId parameter is required' })
    };
  }

  // Default to last 24 hours if no time range specified
  const endTime = queryParams.endTime
    ? parseInt(queryParams.endTime)
    : Math.floor(Date.now() / 1000);

  const startTime = queryParams.startTime
    ? parseInt(queryParams.startTime)
    : endTime - (24 * 3600);

  try {
    // Query DynamoDB
    const items = await queryPlayerData(playerId, startTime, endTime);

    // Aggregate if requested
    const data = aggregateData(items, interval);

    const response = {
      playerId,
      startTime,
      endTime,
      interval,
      dataPoints: data.length,
      data
    };

    // Calculate and publish metrics
    const timeRangeHours = Math.round((endTime - startTime) / 3600);
    const metrics = {
      DataPointsReturned: data.length,
      QueryTimeRangeHours: timeRangeHours
    };
    await publishMetrics(metrics);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error('Error processing request:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Internal server error', message: error.message })
    };
  }
};
