import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, BatchWriteCommand } from "@aws-sdk/lib-dynamodb";
import { CloudWatchClient, PutMetricDataCommand } from "@aws-sdk/client-cloudwatch";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
const docClient = DynamoDBDocumentClient.from(client);
const cloudwatch = new CloudWatchClient({ region: process.env.AWS_REGION || "us-east-1" });

const PLAYER_IDS = (process.env.PLAYER_IDS || "").split(',').map(id => id.trim()).filter(id => id);
const API_BASE_URL = process.env.API_BASE_URL || "https://bcproxy.bitcraft-data.com/proxy";
const DYNAMODB_TABLE = process.env.DYNAMODB_TABLE || "bitcraft-profession-experience";

// Map skill names to our profession keys
const SKILL_NAME_MAP = {
  'Carpentry': 'carpentry',
  'Farming': 'farming',
  'Fishing': 'fishing',
  'Foraging': 'foraging',
  'Forestry': 'forestry',
  'Hunting': 'hunting',
  'Leatherworking': 'leatherworking',
  'Masonry': 'masonry',
  'Mining': 'mining',
  'Scholar': 'scholar',
  'Smithing': 'smithing',
  'Tailoring': 'tailoring'
};

// Fetch player data and extract profession experience
async function fetchProfessionExperience(playerId) {
  const url = `${API_BASE_URL}/api/players/${playerId}`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.error(`Failed to fetch player ${playerId}: ${response.status}`);
      return null;
    }

    const data = await response.json();

    if (!data || !data.player) {
      console.error(`No player data for player ${playerId}`);
      return null;
    }

    const player = data.player;
    const experience = player.experience || [];
    const skillMap = player.skillMap || {};

    // Initialize all professions to 0
    const professions = {
      carpentry: 0,
      farming: 0,
      fishing: 0,
      foraging: 0,
      forestry: 0,
      hunting: 0,
      leatherworking: 0,
      masonry: 0,
      mining: 0,
      scholar: 0,
      smithing: 0,
      tailoring: 0
    };

    // Map experience data using skillMap
    for (const expEntry of experience) {
      const skillId = expEntry.skill_id;
      const quantity = expEntry.quantity || 0;

      if (skillMap[skillId]) {
        const skillName = skillMap[skillId].name;
        const professionKey = SKILL_NAME_MAP[skillName];

        if (professionKey) {
          professions[professionKey] = quantity;
        }
      }
    }

    return professions;
  } catch (error) {
    console.error(`Error fetching player ${playerId}:`, error);
    return null;
  }
}

// Write data to DynamoDB
async function writeToDynamoDB(records) {
  if (records.length === 0) return;

  // DynamoDB BatchWriteItem supports max 25 items
  const batches = [];
  for (let i = 0; i < records.length; i += 25) {
    batches.push(records.slice(i, i + 25));
  }

  for (const batch of batches) {
    const putRequests = batch.map(record => ({
      PutRequest: { Item: record }
    }));

    const command = new BatchWriteCommand({
      RequestItems: {
        [DYNAMODB_TABLE]: putRequests
      }
    });

    try {
      await docClient.send(command);
      console.log(`Wrote batch of ${batch.length} records to DynamoDB`);
    } catch (error) {
      console.error('Error writing to DynamoDB:', error);
      throw error;
    }
  }
}

// Publish custom metrics to CloudWatch
async function publishMetrics(metrics) {
  const metricData = Object.entries(metrics).map(([metricName, value]) => ({
    MetricName: metricName,
    Value: value,
    Unit: metricName.includes('Duration') ? 'Milliseconds' : 'Count',
    Timestamp: new Date()
  }));

  const command = new PutMetricDataCommand({
    Namespace: 'BitcraftProfession',
    MetricData: metricData
  });

  try {
    await cloudwatch.send(command);
    console.log('Published custom metrics:', metrics);
  } catch (error) {
    console.error('Error publishing metrics:', error);
    // Don't throw - metrics publishing failure shouldn't break the main function
  }
}

// Lambda handler
export const handler = async (event) => {
  const startTime = Date.now();
  console.log(`Starting profession data collection for ${PLAYER_IDS.length} players`);

  if (PLAYER_IDS.length === 0) {
    console.warn('No player IDs configured in PLAYER_IDS environment variable');
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'No players configured' })
    };
  }

  const timestamp = Math.floor(Date.now() / 1000);
  const ttl = timestamp + (30 * 24 * 60 * 60); // 30 days from now
  const records = [];
  let playersFailed = 0;

  for (const playerId of PLAYER_IDS) {
    console.log(`Fetching profession data for player ${playerId}`);

    const professions = await fetchProfessionExperience(playerId);

    if (professions) {
      // Skip records where all profession values are 0 (corrupted/missing data)
      const totalXP = Object.values(professions).reduce((sum, val) => sum + val, 0);
      if (totalXP === 0) {
        console.warn(`Skipping player ${playerId}: all profession values are 0 (likely API issue)`);
        playersFailed++;
      } else {
        records.push({
          playerId,
          timestamp,
          ttl,
          ...professions
        });
        console.log(`Player ${playerId}:`, professions);
      }
    } else {
      playersFailed++;
    }

    // Rate limiting: 100ms delay between requests
    if (PLAYER_IDS.indexOf(playerId) < PLAYER_IDS.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  if (records.length > 0) {
    await writeToDynamoDB(records);
    console.log(`Successfully collected and stored data for ${records.length} players`);
  }

  // Calculate metrics
  const duration = Date.now() - startTime;
  const metrics = {
    PlayersProcessed: records.length,
    PlayersFailed: playersFailed,
    DataPointsWritten: records.length,
    PollingCycleDuration: duration
  };

  // Publish metrics to CloudWatch
  await publishMetrics(metrics);

  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Profession data collection completed',
      playersProcessed: records.length,
      playersFailed,
      timestamp
    })
  };
};
